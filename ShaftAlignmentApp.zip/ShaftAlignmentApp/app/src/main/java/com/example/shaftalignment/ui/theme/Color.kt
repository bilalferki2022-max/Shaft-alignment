package com.example.shaftalignment.ui.theme

import androidx.compose.ui.graphics.Color

val BgDark = Color(0xFF0A1120)
val BgCard = Color(0xFF101A30)
val AccentBlue = Color(0xFF29B6F6)
val AccentOrange = Color(0xFFFF7A1A)
val AccentGreen = Color(0xFF3DDC84)
val AccentRed = Color(0xFFEF4444)
val AccentYellow = Color(0xFFFBBF24)
val TextPrimary = Color(0xFFF3F6FA)
val TextMuted = Color(0xFF8FA0B8)
