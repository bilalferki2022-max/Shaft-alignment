package com.example.shaftalignment

import kotlin.math.abs
import kotlin.math.tan
import kotlin.math.PI

/**
 * Core math for pump-motor shaft alignment.
 *
 * Convention (standard "offset + angularity" method used by laser and
 * reverse-dial-indicator alignment systems):
 *   - offsetMm      : the vertical or horizontal gap between the two shaft
 *                     centerlines AT the coupling center, in millimetres.
 *                     Positive = movable machine (motor) centerline is
 *                     ABOVE / to one chosen side of the stationary machine
 *                     (pump) centerline.
 *   - angularityMmPer100 : the slope between the two centerlines, expressed
 *                     as millimetres of separation per 100 mm of shaft
 *                     length (a unit-independent way laser systems report
 *                     angularity). Positive = the gap is opening in the
 *                     direction away from the coupling, towards the motor.
 *
 * Given the distance from the coupling center to each motor foot, the
 * required correction (how much to shim vertically, or slide horizontally)
 * at that foot is:
 *
 *     correction(D) = offsetMm + (angularityMmPer100 / 100.0) * D
 *
 * A positive result means "raise" (vertical) or "move in the positive
 * direction you defined" (horizontal); negative means the opposite.
 */

data class MachineGeometry(
    val distNearFootMm: Double,   // coupling -> near (front) motor foot
    val distFarFootMm: Double     // coupling -> far (rear) motor foot
)

data class PlaneMeasurement(
    val offsetMm: Double,
    val angularityMmPer100: Double
)

data class FootCorrection(
    val nearFootMm: Double,
    val farFootMm: Double
)

enum class ToleranceBand { EXCELLENT, ACCEPTABLE, CORRECT }

data class AlignmentResult(
    val vertical: FootCorrection,
    val horizontal: FootCorrection
)

object AlignmentCalculator {

    fun computeFootCorrection(
        measurement: PlaneMeasurement,
        geometry: MachineGeometry
    ): FootCorrection {
        val slope = measurement.angularityMmPer100 / 100.0
        val near = measurement.offsetMm + slope * geometry.distNearFootMm
        val far = measurement.offsetMm + slope * geometry.distFarFootMm
        return FootCorrection(near, far)
    }

    fun compute(
        geometry: MachineGeometry,
        vertical: PlaneMeasurement,
        horizontal: PlaneMeasurement
    ): AlignmentResult = AlignmentResult(
        vertical = computeFootCorrection(vertical, geometry),
        horizontal = computeFootCorrection(horizontal, geometry)
    )

    /**
     * Rough general-purpose tolerance banding for overall offset/angularity
     * at the coupling, in mm (short-flex coupling, mid-speed pump, as a
     * rule of thumb ONLY). Always replace with the OEM or site-specific
     * tolerance chart (which depends on RPM and coupling type) before
     * accepting a machine into service.
     */
    fun band(valueMm: Double): ToleranceBand {
        val v = abs(valueMm)
        return when {
            v <= 0.05 -> ToleranceBand.EXCELLENT
            v <= 0.10 -> ToleranceBand.ACCEPTABLE
            else -> ToleranceBand.CORRECT
        }
    }

    /** Convert an angle difference (degrees) measured with the phone's
     * tilt sensor on two faces into a laser-style "mm per 100 mm" slope. */
    fun degreesToMmPer100(angleDeltaDeg: Double): Double {
        val rad = angleDeltaDeg * PI / 180.0
        return 100.0 * tan(rad)
    }
}
