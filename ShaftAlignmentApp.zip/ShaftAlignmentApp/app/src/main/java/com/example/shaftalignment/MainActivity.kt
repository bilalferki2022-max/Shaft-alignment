package com.example.shaftalignment

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shaftalignment.ui.theme.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShaftAlignmentTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AlignmentScreen()
                }
            }
        }
    }
}

// ---------------------------------------------------------------- helpers --

private fun String.toMmOrNull(): Double? = this.trim().replace(",", ".").toDoubleOrNull()

@Composable
private fun fmt(v: Double): String = String.format("%.2f", v)

// ------------------------------------------------------------------ screen --

@Composable
fun AlignmentScreen() {
    // --- geometry ---
    var nearFoot by remember { mutableStateOf("100") }
    var farFoot by remember { mutableStateOf("300") }

    // --- vertical plane ---
    var vOffset by remember { mutableStateOf("0.00") }
    var vAngularity by remember { mutableStateOf("0.00") }

    // --- horizontal plane ---
    var hOffset by remember { mutableStateOf("0.00") }
    var hAngularity by remember { mutableStateOf("0.00") }

    val geometry = MachineGeometry(
        distNearFootMm = nearFoot.toMmOrNull() ?: 0.0,
        distFarFootMm = farFoot.toMmOrNull() ?: 0.0
    )
    val vertical = PlaneMeasurement(
        offsetMm = vOffset.toMmOrNull() ?: 0.0,
        angularityMmPer100 = vAngularity.toMmOrNull() ?: 0.0
    )
    val horizontal = PlaneMeasurement(
        offsetMm = hOffset.toMmOrNull() ?: 0.0,
        angularityMmPer100 = hAngularity.toMmOrNull() ?: 0.0
    )
    val result = AlignmentCalculator.compute(geometry, vertical, horizontal)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp)
    ) {
        Text(
            "محاذاة المضخة والمحرك",
            color = TextPrimary,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "Pump \u2013 Motor Shaft Alignment Calculator",
            color = AccentBlue,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
        )
        Spacer(Modifier.height(18.dp))

        SectionCard(title = "1. أبعاد المحرك (Geometry)") {
            LabeledField("قاعدة قريبة \u2013 Near Foot (mm)", nearFoot) { nearFoot = it }
            Spacer(Modifier.height(10.dp))
            LabeledField("قاعدة بعيدة \u2013 Far Foot (mm)", farFoot) { farFoot = it }
            Text(
                "المسافة من مركز الـ Coupling إلى كل قاعدة تثبيت للمحرك",
                color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)
            )
        }

        Spacer(Modifier.height(16.dp))

        SectionCard(title = "2. القياس الرأسي (Vertical)") {
            LabeledField("Offset عند الـ Coupling (mm)", vOffset) { vOffset = it }
            Spacer(Modifier.height(10.dp))
            LabeledField("Angularity (mm / 100mm)", vAngularity) { vAngularity = it }
            Spacer(Modifier.height(10.dp))
            TiltAssist(onApply = { vAngularity = fmt(it) })
        }

        Spacer(Modifier.height(16.dp))

        SectionCard(title = "3. القياس الأفقي (Horizontal)") {
            LabeledField("Offset عند الـ Coupling (mm)", hOffset) { hOffset = it }
            Spacer(Modifier.height(10.dp))
            LabeledField("Angularity (mm / 100mm)", hAngularity) { hAngularity = it }
        }

        Spacer(Modifier.height(16.dp))

        SectionCard(title = "4. النتائج \u2013 تصحيح كل قاعدة (Results)") {
            ResultRow(
                label = "رأسي \u2013 قريبة (Shim)",
                valueMm = result.vertical.nearFootMm,
                positiveWord = "أضف Shims (ارفع)",
                negativeWord = "أزل Shims (اخفض)"
            )
            ResultRow(
                label = "رأسي \u2013 بعيدة (Shim)",
                valueMm = result.vertical.farFootMm,
                positiveWord = "أضف Shims (ارفع)",
                negativeWord = "أزل Shims (اخفض)"
            )
            Spacer(Modifier.height(8.dp))
            ResultRow(
                label = "أفقي \u2013 قريبة (Move)",
                valueMm = result.horizontal.nearFootMm,
                positiveWord = "حرك للاتجاه الموجب",
                negativeWord = "حرك للاتجاه السالب"
            )
            ResultRow(
                label = "أفقي \u2013 بعيدة (Move)",
                valueMm = result.horizontal.farFootMm,
                positiveWord = "حرك للاتجاه الموجب",
                negativeWord = "حرك للاتجاه السالب"
            )
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "\u26A0 أداة مساعدة للتقدير الأولي فقط. لا تُغني عن جهاز Laser Alignment " +
                "معايَر عند التنفيذ النهائي، واتبع دائماً Tolerance المحدد من الشركة المصنعة.",
            color = AccentOrange,
            fontSize = 12.sp,
            modifier = Modifier.padding(bottom = 24.dp)
        )
    }
}

// -------------------------------------------------------------- components --

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = BgCard),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = AccentBlue, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun LabeledField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label, color = TextMuted, fontSize = 13.sp) },
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
            keyboardType = KeyboardType.Number
        ),
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = TextMuted
        )
    )
}

@Composable
private fun ResultRow(label: String, valueMm: Double, positiveWord: String, negativeWord: String) {
    val band = AlignmentCalculator.band(valueMm)
    val bandColor = when (band) {
        ToleranceBand.EXCELLENT -> AccentGreen
        ToleranceBand.ACCEPTABLE -> AccentYellow
        ToleranceBand.CORRECT -> AccentRed
    }
    val direction = if (valueMm >= 0) positiveWord else negativeWord

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Text(direction, color = TextMuted, fontSize = 12.sp)
        }
        Surface(
            color = bandColor.copy(alpha = 0.15f),
            shape = MaterialTheme.shapes.small
        ) {
            Text(
                "${fmt(valueMm)} mm",
                color = bandColor,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
        }
    }
}

/** Assistive vertical-angularity capture using the phone's tilt sensor. */
@Composable
private fun TiltAssist(onApply: (Double) -> Unit) {
    val context = LocalContext.current
    val sensorManager = remember { TiltSensorManager(context) }
    var active by remember { mutableStateOf(false) }
    var motorAngle by remember { mutableStateOf<Double?>(null) }
    var pumpAngle by remember { mutableStateOf<Double?>(null) }

    DisposableEffect(active) {
        if (active) sensorManager.start()
        onDispose { sensorManager.stop() }
    }

    if (!sensorManager.isAvailable) return

    Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Switch(checked = active, onCheckedChange = { active = it })
            Spacer(Modifier.width(8.dp))
            Text("مساعد قياس الميل بالهاتف (تقريبي)", color = TextMuted, fontSize = 12.sp)
        }
        if (active) {
            Spacer(Modifier.height(8.dp))
            Text(
                "الزاوية الحالية: ${fmt(sensorManager.angleDeg)}°",
                color = AccentBlue, fontSize = 13.sp
            )
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { motorAngle = sensorManager.angleDeg }) {
                    Text("التقاط \u2013 المحرك")
                }
                Button(onClick = { pumpAngle = sensorManager.angleDeg }) {
                    Text("التقاط \u2013 المضخة")
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "المحرك: ${motorAngle?.let { fmt(it) } ?: "\u2013"}°   " +
                    "المضخة: ${pumpAngle?.let { fmt(it) } ?: "\u2013"}°",
                color = TextMuted, fontSize = 12.sp
            )
            if (motorAngle != null && pumpAngle != null) {
                val delta = pumpAngle!! - motorAngle!!
                val mmPer100 = AlignmentCalculator.degreesToMmPer100(delta)
                Spacer(Modifier.height(6.dp))
                Text(
                    "الفرق \u2192 Angularity \u2248 ${fmt(mmPer100)} mm/100mm",
                    color = AccentGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = { onApply(mmPer100) }) {
                    Text("استخدم هذه القيمة")
                }
            }
        }
    }
}
