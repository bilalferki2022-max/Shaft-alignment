package com.example.shaftalignment

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.atan2

/**
 * Reads the phone's accelerometer and exposes the current tilt angle
 * (degrees) around the shaft axis, for use as a ROUGH, assistive way to
 * capture angularity: rest the phone flat against a machined reference
 * face on the motor, capture, then against the equivalent face on the
 * pump, capture again. The app takes the difference.
 *
 * This is NOT a substitute for a calibrated laser alignment system -
 * phone accelerometers are only accurate to roughly +/-0.5-1 degree,
 * which is fine for a rough / pre-alignment check but not for final
 * precision tolerancing.
 */
class TiltSensorManager(context: Context) : SensorEventListener {

    private val sensorManager =
        context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? =
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    var angleDeg by mutableStateOf(0.0)
        private set

    var isAvailable: Boolean = accelerometer != null
        private set

    fun start() {
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val x = event.values[0]
        val z = event.values[2]
        // Angle of tilt around the shaft axis when the phone is held flat
        // against a vertical machined face (screen facing outward).
        angleDeg = Math.toDegrees(atan2(x.toDouble(), z.toDouble()))
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // no-op
    }
}
